package com.emanuel.optimizer;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class OptimizerScreen extends Screen {
    private final Screen parent;
    private ButtonWidget fpsBtn, mushBtn;

    public OptimizerScreen(Screen parent) {
        super(Text.literal("Emanuel Mega Optimizer"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int w = 150, h = 20, gap = 6;
        int left = this.width / 2 - w - gap / 2;
        int right = this.width / 2 + gap / 2;
        int y = 34;
        Preset[] ps = Preset.values();
        for (int i = 0; i < ps.length; i++) {
            Preset p = ps[i];
            int x = (i % 2 == 0) ? left : right;
            int yy = y + (i / 2) * (h + gap);
            addDrawableChild(ButtonWidget.builder(Text.literal(p.label), b -> {
                p.apply(this.client);
            }).dimensions(x, yy, w, h).build());
        }
        int y2 = y + 3 * (h + gap) + 4;
        fpsBtn = addDrawableChild(ButtonWidget.builder(fpsText(), b -> {
            EmanuelOptimizerClient.autoFps = !EmanuelOptimizerClient.autoFps;
            EmanuelOptimizerClient.save();
            b.setMessage(fpsText());
        }).dimensions(left, y2, w, h).build());
        mushBtn = addDrawableChild(ButtonWidget.builder(mushText(), b -> {
            EmanuelOptimizerClient.autoMush = !EmanuelOptimizerClient.autoMush;
            EmanuelOptimizerClient.save();
            b.setMessage(mushText());
        }).dimensions(right, y2, w, h).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Fechar"), b -> this.close())
                .dimensions(this.width / 2 - 75, y2 + h + gap, 150, h).build());
    }

    private Text fpsText() {
        return Text.literal("Auto-FPS: " + (EmanuelOptimizerClient.autoFps ? "LIGADO" : "DESLIGADO"));
    }

    private Text mushText() {
        return Text.literal("Auto Mush: " + (EmanuelOptimizerClient.autoMush ? "LIGADO" : "DESLIGADO"));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("§6§lEmanuel Mega Optimizer"),
                this.width / 2, 10, 0xFFFFFFFF);
        ctx.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("Preset atual: " + EmanuelOptimizerClient.current.label), this.width / 2, 22, 0xFFAAAAAA);
        ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Criado por Emanuel"),
                this.width / 2, this.height - 12, 0xFF888888);
    }

    @Override
    public void close() {
        this.client.setScreen(parent);
    }
}
