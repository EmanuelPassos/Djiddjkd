package com.emanuel.optimizer;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.io.*;
import java.nio.file.Path;
import java.util.Properties;

/** Emanuel Mega Optimizer - criado por Emanuel. */
public class EmanuelOptimizerClient implements ClientModInitializer {
    public static Preset current = Preset.BALANCED;
    public static boolean autoFps = true;
    public static boolean autoMush = true;
    private static KeyBinding menuKey;
    private int tick = 0;

    private static Path cfg() {
        return FabricLoader.getInstance().getConfigDir().resolve("emanuel_optimizer.properties");
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("preset", current.name());
        p.setProperty("autoFps", String.valueOf(autoFps));
        p.setProperty("autoMush", String.valueOf(autoMush));
        try (OutputStream out = new FileOutputStream(cfg().toFile())) {
            p.store(out, "Emanuel Mega Optimizer");
        } catch (IOException ignored) {}
    }

    private static void load() {
        File f = cfg().toFile();
        if (!f.exists()) return;
        Properties p = new Properties();
        try (InputStream in = new FileInputStream(f)) {
            p.load(in);
            current = Preset.valueOf(p.getProperty("preset", "BALANCED"));
            autoFps = Boolean.parseBoolean(p.getProperty("autoFps", "true"));
            autoMush = Boolean.parseBoolean(p.getProperty("autoMush", "true"));
        } catch (Exception ignored) {}
    }

    @Override
    public void onInitializeClient() {
        load();
        KeyBinding.Category cat = KeyBinding.Category.create(Identifier.of("emanuelopt", "main"));
        menuKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.emanuelopt.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_X, cat));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (menuKey.wasPressed()) {
                if (mc.currentScreen == null) mc.setScreen(new OptimizerScreen(null));
            }
            if (autoFps && mc.world != null && ++tick >= 60) {
                tick = 0;
                adaptiveRenderDistance(mc);
            }
        });

        // Preset automático ao entrar no Mush MC
        ClientPlayConnectionEvents.JOIN.register((handler, sender, mc) -> {
            if (!autoMush) return;
            ServerInfo si = mc.getCurrentServerEntry();
            if (si != null && si.address != null && si.address.toLowerCase().contains("mush")) {
                mc.execute(() -> Preset.MUSH.apply(mc));
            }
        });
    }

    /** Ajusta a distância de renderização sozinho conforme o FPS. */
    private void adaptiveRenderDistance(MinecraftClient mc) {
        int fps = mc.getCurrentFps();
        int dist = mc.options.getViewDistance().getValue();
        int cap = Math.max(current.render, 4);
        if (fps < 30 && dist > 3) mc.options.getViewDistance().setValue(dist - 1);
        else if (fps > 80 && dist < cap) mc.options.getViewDistance().setValue(dist + 1);
    }
}
