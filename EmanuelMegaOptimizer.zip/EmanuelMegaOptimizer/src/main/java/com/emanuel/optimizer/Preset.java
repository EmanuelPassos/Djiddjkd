package com.emanuel.optimizer;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.SimpleOption;

public enum Preset {
    // particulas: 0 = todas, 1 = reduzidas, 2 = minimas
    POTATO("Celular/PC Fraco", 4, 5, 0.5, 2, 0, 0, 60, false),
    BALANCED("Equilibrado", 8, 6, 0.8, 1, 1, 1, 120, false),
    PVP("PvP", 8, 6, 1.0, 2, 0, 0, 260, false),
    EVENT500("Evento 500 pessoas", 5, 5, 0.5, 2, 0, 0, 120, false),
    BEDWARS("BedWars", 6, 5, 0.8, 2, 0, 0, 260, false),
    MUSH("Mush MC", 7, 5, 1.0, 2, 0, 0, 260, false);

    public final String label;
    public final int render, sim, particles, biome, mip, fps;
    public final double entity;
    public final boolean vsync;

    Preset(String label, int render, int sim, double entity, int particles,
           int biome, int mip, int fps, boolean vsync) {
        this.label = label; this.render = render; this.sim = sim; this.entity = entity;
        this.particles = particles; this.biome = biome; this.mip = mip;
        this.fps = fps; this.vsync = vsync;
    }

    /** Define uma opcao de enum pelo indice (evita depender do nome da classe). */
    @SuppressWarnings({"unchecked", "rawtypes"})
    private static void setByIndex(SimpleOption opt, int idx) {
        Object cur = opt.getValue();
        if (cur instanceof Enum e) {
            Object[] all = e.getDeclaringClass().getEnumConstants();
            opt.setValue(all[Math.max(0, Math.min(idx, all.length - 1))]);
        }
    }

    public void apply(MinecraftClient mc) {
        GameOptions o = mc.options;
        o.getViewDistance().setValue(render);
        o.getSimulationDistance().setValue(sim);
        o.getEntityDistanceScaling().setValue(entity);
        setByIndex(o.getParticles(), particles);
        setByIndex(o.getCloudRenderMode(), 0); // nuvens desligadas
        o.getBiomeBlendRadius().setValue(biome);
        o.getMipmapLevels().setValue(mip);
        o.getMaxFps().setValue(fps);
        o.getEnableVsync().setValue(vsync);
        o.getEntityShadows().setValue(false);
        o.getAo().setValue(this == BALANCED);
        o.getBobView().setValue(false);
        o.write();
        EmanuelOptimizerClient.current = this;
        EmanuelOptimizerClient.save();
    }
}
