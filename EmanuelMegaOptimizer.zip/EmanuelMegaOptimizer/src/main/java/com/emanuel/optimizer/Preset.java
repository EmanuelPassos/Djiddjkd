package com.emanuel.optimizer;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.ParticlesMode;

public enum Preset {
    POTATO("Celular/PC Fraco", 4, 5, 0.5, ParticlesMode.MINIMAL, 0, 0, 60, false),
    BALANCED("Equilibrado", 8, 6, 0.8, ParticlesMode.DECREASED, 1, 1, 120, false),
    PVP("PvP", 8, 6, 1.0, ParticlesMode.MINIMAL, 0, 0, 260, false),
    EVENT500("Evento 500 pessoas", 5, 5, 0.5, ParticlesMode.MINIMAL, 0, 0, 120, false),
    BEDWARS("BedWars", 6, 5, 0.8, ParticlesMode.MINIMAL, 0, 0, 260, false),
    MUSH("Mush MC", 7, 5, 1.0, ParticlesMode.MINIMAL, 0, 0, 260, false);

    public final String label;
    public final int render, sim, biome, mip, fps;
    public final double entity;
    public final ParticlesMode particles;
    public final boolean vsync;

    Preset(String label, int render, int sim, double entity, ParticlesMode particles,
           int biome, int mip, int fps, boolean vsync) {
        this.label = label; this.render = render; this.sim = sim; this.entity = entity;
        this.particles = particles; this.biome = biome; this.mip = mip;
        this.fps = fps; this.vsync = vsync;
    }

    public void apply(MinecraftClient mc) {
        GameOptions o = mc.options;
        o.getViewDistance().setValue(render);
        o.getSimulationDistance().setValue(sim);
        o.getEntityDistanceScaling().setValue(entity);
        o.getParticles().setValue(particles);
        o.getBiomeBlendRadius().setValue(biome);
        o.getMipmapLevels().setValue(mip);
        o.getMaxFps().setValue(fps);
        o.getEnableVsync().setValue(vsync);
        o.getEntityShadows().setValue(false);
        o.getAo().setValue(this == BALANCED);
        o.getBobView().setValue(false);
        o.getGraphicsMode().setValue(GraphicsMode.FAST);
        o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
        o.write();
        EmanuelOptimizerClient.current = this;
        EmanuelOptimizerClient.save();
    }
}
